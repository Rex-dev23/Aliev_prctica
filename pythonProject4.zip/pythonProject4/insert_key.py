import mysql.connector

# Подключение к базе данных
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="ref_teg"
)

if connection.is_connected():
    print("Подключено")

    # Получение уникального ключа из базы данных
    user_id = 1
    cursor = connection.cursor()
    query = "SELECT invitation_link FROM referral_links WHERE user_id = %s"
    values = (user_id,)
    cursor.execute(query, values)

    result = cursor.fetchone()

    if result:
        invitation_link = result[0]

        # Вставка уникального ключа в HTML-код
        with open("index.html", "r") as file:
            html_content = file.read()

        html_content = html_content.replace("<!-- Вставка уникального ключа из базы данных -->",
                                            f'<h3>Уникальный ключ:</h3><p>{invitation_link}</p>')

        with open("index.html", "w") as file:
            file.write(html_content)

    else:
        print("Уникальный ключ не найден.")

    cursor.close()
    connection.close()
else:
    print("Ошибка подключения к базе данных.")