<script>
  // Анимация появления видео при загрузке страницы
  document.addEventListener("DOMContentLoaded", function () {
    const videoItems = document.querySelectorAll(".video-item");
    videoItems.forEach(function (item) {
      item.classList.add("show");
    });
  });
</script>
