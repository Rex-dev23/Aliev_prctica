import telebot
import config
import time
import random
import string
import pymysql
from baza import host, user, password, db_name

from telebot import types

bot = telebot.TeleBot(config.TOKEN)
try:
    connection = pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=db_name
    )
    print('Подключено')
    print('#' * 20)
except Exception as ex:
    print('Не подключено')
    print(ex)

# Функция для генерации уникальной ссылки-приглашения
def generate_invitation_link():
    letters = string.ascii_letters + string.digits
    invitation_link = ''.join(random.choice(letters) for _ in range(10))
    return invitation_link

# Функция для сохранения ссылки-приглашения в базе данных
def save_invitation_link(user_id, invitation_link, connection):
    cursor = connection.cursor()

    query = "INSERT INTO referral_links (user_id, invitation_link) VALUES (%s, %s)"
    values = (user_id, invitation_link)
    cursor.execute(query, values)

    connection.commit()
    cursor.close()

# Функция для получения ссылки-приглашения из базы данных
def get_invitation_link(user_id, connection):
    cursor = connection.cursor()

    query = "SELECT invitation_link FROM referral_links WHERE user_id = %s"
    values = (user_id,)
    cursor.execute(query, values)

    result = cursor.fetchone()

    cursor.close()

    if result:
        return result[0]
    else:
        return None

@bot.message_handler(commands=['start'])
def welcome(message):
    # keyboard
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item = types.KeyboardButton("Больше информации о нашем курсе")
    markup.add(item)

    bot.send_message(message.chat.id,
                     "Добро пожаловать, {0.first_name}!\nЯ - <b>{1.first_name}</b>, бот созданный чтобы подопытным кроликом.".format(
                         message.from_user, bot.get_me()),
                     parse_mode='html', reply_markup=markup)

    # Проверяем, есть ли ссылка-приглашение у пользователя
    invitation_link = get_invitation_link(message.from_user.id, connection)

    if invitation_link is None:
        # Генерируем новую ссылку-приглашение
        invitation_link = generate_invitation_link()

        # Сохраняем ссылку-приглашение в базе данных
        save_invitation_link(message.from_user.id, invitation_link, connection)

    bot.send_message(message.chat.id, "Ваша уникальная ссылка-приглашение: {}".format(invitation_link))


@bot.message_handler(content_types=['text'])
def lalala(message):
    if message.chat.type == 'private':
        if message.text == 'Больше информации о нашем курсе':
            photo = open('0cd8025f71357ab13c9993c478c63b48.jpg', 'rb')
            bot.send_photo(message.chat.id, photo)
            text = 'Курс программирования - это отличная возможность для тех, кто хочет начать карьеру в IT-индустрии или улучшить свои навыки в программировании. Наш курс предоставляет ученикам все необходимые знания и инструменты для создания качественного программного обеспечения. Мы уделяем особое внимание практическим навыкам, чтобы наши ученики могли применять свои знания в реальных проектах. Наши опытные преподаватели помогут вам разобраться в сложных концепциях программирования и научат вас использовать современные инструменты и технологии.'
            for sentence in text.split('. '):
                bot.send_message(message.chat.id, sentence)
                time.sleep(1)

            video = open('elem8437_video.mp4', 'rb')
            bot.send_video(message.chat.id, video)

            bot.send_message(message.chat.id,
                             text='Курсы по программированию были разработаны более 70 за последние 7 месяцев. Наши курсы ориентированы на быстрое освоение навыков программирования с нуля, получение реального опыта разработки проектов и начало заработка как программист уже через 3-6 месяцев.\n\nМы предлагаем курсы по различным языкам программирования и фреймворкам, включая Python, JavaScript, React, Vue.js, Angular, Java, C++, Swift и многие другие.\n\nНаши курсы подходят как для новичков, так и для программистов со стажем, которые хотят повысить свой уровень и стать востребованными специалистами или сменить направление в программировании.\n\nМы постоянно обновляем наши курсы, следим за последними трендами в IT и добавляем новые направления.')
            bot.send_message(message.chat.id, 'Дополнительную информацию вы можете найти на нашем сайте: http://gamessv7.beget.tech/')  # Замените [Ваша ссылка] на фактическую ссылку

        else:
            bot.send_message(message.chat.id, 'Ожидайте, вам скоро ответит админ')

bot.polling(none_stop=True)
