host = 'localhost'
user = 'root'
password = ''
db_name= 'ref_teg'